#--------------------------------------------------------------------------------------------------------------
# This is a Python3 script to extract DHSVM 3-hour for CONUS runs 


#--------------------------------------------------------------------------------------------------------------
import numpy as np
import os
import copy
import math
import re
import csv
import shutil
import datetime
import pandas as pd
import scipy
import os.path
# from joblib import Parallel, delayed  
# import multiprocessing
from mpi4py import MPI


#--------------------------------------------------------------------------------------------------------------
def npnan(x,y):
	#this function creates the np.nan 2d-array (np.nan should be float)
 	array_2d = np.zeros((x,y), float) 
 	array_2d[:] = np.nan
 	return array_2d

#--------------------------------------------------------------------------------------------------------------
def finddate(year,month,day,var):
	#given year month day and find the index number in the var array
	#if the year/month/day is not in the var, return the last day of var 
	#input year/month/day: int
	var = var[:,:3]        #only contains the date
	var = var.astype(int)  #float to int
	date = np.array([year,month,day])
	temp = np.where(np.all(var==date, axis=1))  #return a tuple
	try:
		m = int(temp[0])
	except:
		m = len(var[:, 0])-1
	return m



#--------------------------------------------------------------------------------------------------------------
# starts here
num_cell = 207173

# load the lat, lon, and cluster
coor = npnan(num_cell, 3) # 0-lat, 1-lon, 2-cluster id (1-5)
file_name = '/rcfs/projects/estcp_ngidf/hongxiang/Arcgis/arcpy/cluster_conus.csv'
lines = [line.rstrip('\n') for line in open(file_name)]
lines = lines[1:]
count = 0
for line in lines:
	item = line.split(',')
	coor[count, 0] = float(item[1])  # lat
	coor[count, 1] = float(item[2])  # lon
	coor[count, 2] = float(item[3])  # cluster ID
	count += 1





# load the datefile
file_path = './datetime_24h'
lines = [line.rstrip('\n') for line in open(file_path)]	
datetime_24h = npnan(23375, 3)
count = 0
for line in lines:
	item = line.split()  # any space
	for j in range(len(item)):
		datetime_24h[count, j] = float(item[j])
	count += 1




comm = MPI.COMM_WORLD
rank = comm.Get_rank()     # the process ID (integer 0-22 for 23-process run)
size = 240                 # the total amount of process requested, define in the command, 1-24 for hydronet

# split cells for each processors
rank_cell = math.floor(num_cell/size)   #863
last_rank_cell = num_cell - rank_cell*(size-1)  #916

# assign number of cells into each processors
if rank < (size-1):    # not the last rank
	loop_cell = rank_cell
else:                  # the last rank
	loop_cell = last_rank_cell





# --------------------------------------------------------------------------------------------------------------
# loop through each cell
# def gen_ascii(i, coor, datetime_24h):

for m in range(loop_cell):


	num_daily = 23375
	output_24h = npnan(num_daily, 6)  # 0-year, 1-mon, 2-day, 3-W_veg (mm), 4-P (mm), 5-P_int (mm)

	output_24h[:,0:3] = datetime_24h



	# load the data
	file_path = './24-h_time_series/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	lines = [line.rstrip('\n') for line in open(file_path)]	

	# load the daily time series first
	count = 0
	for line in lines:
		item = line.split()  # any space

		output_24h[count, 3] = float(item[0])
		output_24h[count, 4] = float(item[1])
		output_24h[count, 5] = float(item[2])

		count += 1



	# agg data into 48hour
	output_48h = npnan(num_daily-1, 6)
	for k in range(num_daily-1):
		output_48h[k,0:3] = output_24h[k+1,0:3]
		output_48h[k,3] = output_24h[k+1,3] + output_24h[k,3]
		output_48h[k,4] = output_24h[k+1,4] + output_24h[k,4]
		output_48h[k,5] = output_24h[k+1,5] + output_24h[k,5]


	# agg data into 72hour
	output_72h = npnan(num_daily-2, 6)
	for k in range(num_daily-2):
		output_72h[k,0:3] = output_24h[k+2,0:3]
		output_72h[k,3] = output_24h[k+2,3] + output_24h[k+1,3] + output_24h[k,3]
		output_72h[k,4] = output_24h[k+2,4] + output_24h[k+1,4] + output_24h[k,4]
		output_72h[k,5] = output_24h[k+2,5] + output_24h[k+1,5] + output_24h[k,5]



	s_yr = 1950
	e_yr = 2013
	num_year = e_yr - s_yr + 1

	annual_max_24h_W_veg = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_24h_P     = npnan(num_year, 4)  # 0-year, month, day
	annual_max_24h_P_int = npnan(num_year, 4)  # 0-year, month, day

	annual_max_48h_W_veg = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_48h_P     = npnan(num_year, 4)  # 0-year, month, day
	annual_max_48h_P_int = npnan(num_year, 4)  # 0-year, month, day

	annual_max_72h_W_veg = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_72h_P     = npnan(num_year, 4)  # 0-year, month, day
	annual_max_72h_P_int = npnan(num_year, 4)  # 0-year, month, day








	# extract the annual maximum value
	count = 0
	for yr in range(s_yr, e_yr+1):

		year_data_24h = output_24h[output_24h[:,0]==yr,:]
		year_data_48h = output_48h[output_48h[:,0]==yr,:]
		year_data_72h = output_72h[output_72h[:,0]==yr,:]




		annual_max_24h_W_veg[count, 3] = np.max(year_data_24h[:,3])
		annual_max_24h_W_veg[count, 0:3] = year_data_24h[np.argmax(year_data_24h[:,3]), 0:3]

		annual_max_24h_P[count, 3] = np.max(year_data_24h[:,4])
		annual_max_24h_P[count, 0:3] = year_data_24h[np.argmax(year_data_24h[:,4]), 0:3]

		annual_max_24h_P_int[count, 3] = np.max(year_data_24h[:,5])
		annual_max_24h_P_int[count, 0:3] = year_data_24h[np.argmax(year_data_24h[:,5]), 0:3]





		annual_max_48h_W_veg[count, 3] = np.max(year_data_48h[:,3])
		annual_max_48h_W_veg[count, 0:3] = year_data_48h[np.argmax(year_data_48h[:,3]), 0:3]

		annual_max_48h_P[count, 3] = np.max(year_data_48h[:,4])
		annual_max_48h_P[count, 0:3] = year_data_48h[np.argmax(year_data_48h[:,4]), 0:3]		

		annual_max_48h_P_int[count, 3] = np.max(year_data_48h[:,5])
		annual_max_48h_P_int[count, 0:3] = year_data_48h[np.argmax(year_data_48h[:,5]), 0:3]





		annual_max_72h_W_veg[count, 3] = np.max(year_data_72h[:,3])
		annual_max_72h_W_veg[count, 0:3] = year_data_72h[np.argmax(year_data_72h[:,3]), 0:3]

		annual_max_72h_P[count, 3] = np.max(year_data_72h[:,4])
		annual_max_72h_P[count, 0:3] = year_data_72h[np.argmax(year_data_72h[:,4]), 0:3]

		annual_max_72h_P_int[count, 3] = np.max(year_data_72h[:,5])
		annual_max_72h_P_int[count, 0:3] = year_data_72h[np.argmax(year_data_72h[:,5]), 0:3]

		count+=1










	# save the output


	outputfile = './24-h_AM_time_series/W_veg/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_24h_W_veg, fmt='%d %d %d %5.4f')

	outputfile = './24-h_AM_time_series/P_int/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_24h_P_int, fmt='%d %d %d %5.4f')

	outputfile = './24-h_AM_time_series/P/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_24h_P, fmt='%d %d %d %5.4f')





	outputfile = './48-h_AM_time_series/W_veg/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_48h_W_veg, fmt='%d %d %d %5.4f')

	outputfile = './48-h_AM_time_series/P/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_48h_P, fmt='%d %d %d %5.4f')

	outputfile = './48-h_AM_time_series/P_int/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_48h_P_int, fmt='%d %d %d %5.4f')






	outputfile = './72-h_AM_time_series/W_veg/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_72h_W_veg, fmt='%d %d %d %5.4f')

	outputfile = './72-h_AM_time_series/P_int/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_72h_P_int, fmt='%d %d %d %5.4f')

	outputfile = './72-h_AM_time_series/P/data_%8.5f_%9.5f'   %(coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
	np.savetxt(outputfile, annual_max_72h_P, fmt='%d %d %d %5.4f')



	# monitor the process
	print(rank, m, loop_cell, coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])





# num_cores = multiprocessing.cpu_count()
# num_cores = 48
# Parallel(n_jobs=num_cores)(delayed(gen_ascii)(i, coor, datetime_24h) for i in range(num_cell))





