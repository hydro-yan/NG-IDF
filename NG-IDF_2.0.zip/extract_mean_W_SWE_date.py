#--------------------------------------------------------------------------------------------------------------
# This is a Python3 script used to detrend the annual maximum datas for CONUS
# written by Hongxiang Yan at PNNL on May 25, 2018
#--------------------------------------------------------------------------------------------------------------
import numpy as np
import os
import copy
import math
import re
import csv
import shutil
import datetime
import pandas as pd
import scipy
import os.path
from joblib import Parallel, delayed  
import multiprocessing



#--------------------------------------------------------------------------------------------------------------
def npnan(x,y):
	#this function creates the np.nan 2d-array (np.nan should be float)
 	array_2d = np.zeros((x,y), float) 
 	array_2d[:] = np.nan
 	return array_2d

#--------------------------------------------------------------------------------------------------------------
	# input mon and day, return Julian number
def findJulian(mon, day, Julian_date):
	var = Julian_date[:,:2]
	var = var.astype(int)  #float to int
	date = np.array([mon,day])
	temp = np.where(np.all(var==date, axis=1))  #return a tuple
	try:
		m = int(temp[0])
	except:
		return 59  # 59 for Julian, 151 for water
	return Julian_date[m,2]


#--------------------------------------------------------------------------------------------------------------
	# input mon and day, return Julian number
def findWater(mon, day, Julian_date):
	var = Julian_date[:,:2]
	var = var.astype(int)  #float to int
	date = np.array([mon,day])
	temp = np.where(np.all(var==date, axis=1))  #return a tuple
	try:
		m = int(temp[0])
	except:
		return 151  # 59 for Julian, 151 for water
	return Julian_date[m,2]



#--------------------------------------------------------------------------------------------------------------
def findMD(a):   # a is the time series of Julian date
    a = a/365*(2*math.pi)

    x = sum(np.cos(a))/len(a)
    y = sum(np.sin(a))/len(a)
    b = np.arctan(y/x)
    


    if (x<0):
        b = math.pi + b
    if (y<0 and x>0):
        b = 2*math.pi + b

    MD = b*365/(2*math.pi)
    return MD


#--------------------------------------------------------------------------------------------------------------
def findSI(a):
    a = a/365*(2*math.pi)
    x = sum(np.cos(a))/len(a)
    y = sum(np.sin(a))/len(a)
    SI = np.sqrt(x*x+y*y)
    return SI




#--------------------------------------------------------------------------------------------------------------
# load the datefile
file_path = './datetime_24h'
lines = [line.rstrip('\n') for line in open(file_path)]	
datetime_24h = npnan(23375, 3)
count = 0
for line in lines:
	item = line.split()  # any space
	for j in range(len(item)):
		datetime_24h[count, j] = float(item[j])
	count += 1




#--------------------------------------------------------------------------------------------------------------
# load Julian date conversion table for non-leaping year
Julian_date = npnan(365, 3) #0-month, 1-day, 2-Julidan day
file = './JulianDate.txt'
lines = [line.rstrip('\n') for line in open(file)]	
count = 0
for line in lines:
	item = line.split()	
	for j in range(len(item)):
		Julian_date[count, j] = float(item[j])
	count +=1



Water_date = npnan(365, 3) #0-month, 1-day, 2-Julidan day
file = './WaterDate.txt'
lines = [line.rstrip('\n') for line in open(file)]	
count = 0
for line in lines:
	item = line.split()	
	for j in range(len(item)):
		Water_date[count, j] = float(item[j])
	count +=1


#--------------------------------------------------------------------------------------------------------------
# starts here
num_cell = 207173

# load the lat, lon, and cluster
coor = npnan(num_cell, 3) # 0-lat, 1-lon, 2-cluster id (1-5)
file_name = './cluster_conus.csv'
lines = [line.rstrip('\n') for line in open(file_name)]
lines = lines[1:]
count = 0
for line in lines:
	item = line.split(',')
	coor[count, 0] = float(item[1])  # lat
	coor[count, 1] = float(item[2])  # lon
	coor[count, 2] = float(item[3])  # cluster ID
	count += 1



#--------------------------------------------------------------------------------------------------------------
var_name1 = ['AM_time_series_CY', 'AM_time_series_WY']
var_name2 = ['24-h_AM_time_series', '48-h_AM_time_series', '72-h_AM_time_series', 'SWE_AM_time_series']

for kk in range(len(var_name1)):

	peak_var = npnan(num_cell, 7) # 0-lat, 1-lon, 2-month, 3-day, 4-julian/water day, 5-mean W/SWE value, 6-SI index
	peak_var[:,0:2] = coor[:,0:2]

	for jj in range(len(var_name2)):

		for i in range(num_cell):

			if jj<=2:
				file_name = './%s/%s/W/data_%5.5f_%5.5f'   %(var_name1[kk], var_name2[jj], coor[i,0], coor[i,1])
			if jj==3:
				file_name = './%s/%s/data_%5.5f_%5.5f'   %(var_name1[kk], var_name2[jj], coor[i,0], coor[i,1])


			lines = [line.rstrip('\n') for line in open(file_name)]	
			if kk==0:
				lines = lines[1:]    
			assert(len(lines)==63)

			var = npnan(len(lines), 5)  #0-year, 1-mon, 2-day, 3-AM value (mm), 4-Julian/Water date
			day = 0
			for line in lines:
				item = line.split()
				for j in range(4):
					var[day, j] = float(item[j])
				if kk==0:
					var[day, 4] = findJulian(var[day, 1], var[day, 2], Julian_date)
				if kk==1:
					var[day, 4] = findWater(var[day, 1], var[day, 2], Water_date)
				day += 1


			peak_var[i,5] = np.mean(var[:,3])



			MD = findMD(var[:,4])
			SI = findSI(var[:,4])

			MD_int = int(MD)

			if MD_int <1:
				MD_int = 1
			
			if kk ==0:
				month = Julian_date[Julian_date[:,2]==MD_int,0]
				day   = Julian_date[Julian_date[:,2]==MD_int,1]
			if kk ==1:
				month = Water_date[Water_date[:,2]==MD_int,0]
				day   = Water_date[Water_date[:,2]==MD_int,1]				

			peak_var[i,2] = month
			peak_var[i,3] = day
			peak_var[i,4] = MD
			peak_var[i,6] = SI

			

			print(kk, jj, i)



		if kk==0 and jj==0:
			file = './IDF_curves_CY/mean_AM_24-h_W_dates' 
		if kk==0 and jj==1:
			file = './IDF_curves_CY/mean_AM_48-h_W_dates' 
		if kk==0 and jj==2:
			file = './IDF_curves_CY/mean_AM_72-h_W_dates' 			
		if kk==0 and jj==3:
			file = './IDF_curves_CY/mean_AM_SWE_dates' 	

		if kk==1 and jj==0:
			file = './IDF_curves_WY/mean_AM_24-h_W_dates' 
		if kk==1 and jj==1:
			file = './IDF_curves_WY/mean_AM_48-h_W_dates' 
		if kk==1 and jj==2:
			file = './IDF_curves_WY/mean_AM_72-h_W_dates' 			
		if kk==1 and jj==3:
			file = './IDF_curves_WY/mean_AM_SWE_dates' 	



		np.savetxt(file, peak_var, fmt='%6.5f %6.5f %d %d %3.2f %7.6f %7.6f')


























