#--------------------------------------------------------------------------------------------------------------
# This is a Python3 script to extract DHSVM 3-hour for CONUS runs 


#--------------------------------------------------------------------------------------------------------------
import numpy as np
import os
import copy
import math
import re
import csv
import shutil
import datetime
import pandas as pd
import scipy
import os.path
from joblib import Parallel, delayed  
import multiprocessing

#--------------------------------------------------------------------------------------------------------------
def npnan(x,y):
	#this function creates the np.nan 2d-array (np.nan should be float)
 	array_2d = np.zeros((x,y), float) 
 	array_2d[:] = np.nan
 	return array_2d

#--------------------------------------------------------------------------------------------------------------
def finddate(year,month,day,var):
	#given year month day and find the index number in the var array
	#if the year/month/day is not in the var, return the last day of var 
	#input year/month/day: int
	var = var[:,:3]        #only contains the date
	var = var.astype(int)  #float to int
	date = np.array([year,month,day])
	temp = np.where(np.all(var==date, axis=1))  #return a tuple
	try:
		m = int(temp[0])
	except:
		print('cannot find date')
		exit()
	return m



#--------------------------------------------------------------------------------------------------------------
# starts here
num_cell = 207173

# load the lat, lon, and cluster
coor = npnan(num_cell, 3) # 0-lat, 1-lon, 2-cluster id (1-5)
file_name = '../cluster_conus.csv'
lines = [line.rstrip('\n') for line in open(file_name)]
lines = lines[1:]
count = 0
for line in lines:
	item = line.split(',')
	coor[count, 0] = float(item[1])  # lat
	coor[count, 1] = float(item[2])  # lon
	coor[count, 2] = float(item[3])  # cluster ID
	count += 1





# load the datefile
file_path = './datetime_24h'
lines = [line.rstrip('\n') for line in open(file_path)]	
datetime_24h = npnan(23375, 3)
count = 0
for line in lines:
	item = line.split()  # any space
	for j in range(len(item)):
		datetime_24h[count, j] = float(item[j])
	count += 1




# if path doesnot exist, create path
if not os.path.isdir('./AM_time_series_WY/24-h_AM_time_series'):
	os.mkdir('./AM_time_series_WY/24-h_AM_time_series')	

if not os.path.isdir('./AM_time_series_WY/48-h_AM_time_series'):
	os.mkdir('./AM_time_series_WY/48-h_AM_time_series')

if not os.path.isdir('./AM_time_series_WY/72-h_AM_time_series'):
	os.mkdir('./AM_time_series_WY/72-h_AM_time_series')

if not os.path.isdir('./AM_time_series_WY/SWE_AM_time_series'):
	os.mkdir('./AM_time_series_WY/SWE_AM_time_series')	


if not os.path.isdir('./AM_time_series_WY/24-h_AM_time_series/W'):
	os.mkdir('./AM_time_series_WY/24-h_AM_time_series/W')

if not os.path.isdir('./AM_time_series_WY/24-h_AM_time_series/TF'):
	os.mkdir('./AM_time_series_WY/24-h_AM_time_series/TF')

if not os.path.isdir('./AM_time_series_WY/24-h_AM_time_series/Melt'):
	os.mkdir('./AM_time_series_WY/24-h_AM_time_series/Melt')

if not os.path.isdir('./AM_time_series_WY/24-h_AM_time_series/ROS'):
	os.mkdir('./AM_time_series_WY/24-h_AM_time_series/ROS')

if not os.path.isdir('./AM_time_series_WY/24-h_AM_time_series/Rain'):
	os.mkdir('./AM_time_series_WY/24-h_AM_time_series/Rain')



if not os.path.isdir('./AM_time_series_WY/48-h_AM_time_series/W'):
	os.mkdir('./AM_time_series_WY/48-h_AM_time_series/W')

if not os.path.isdir('./AM_time_series_WY/48-h_AM_time_series/TF'):
	os.mkdir('./AM_time_series_WY/48-h_AM_time_series/TF')

if not os.path.isdir('./AM_time_series_WY/48-h_AM_time_series/Melt'):
	os.mkdir('./AM_time_series_WY/48-h_AM_time_series/Melt')

if not os.path.isdir('./AM_time_series_WY/48-h_AM_time_series/ROS'):
	os.mkdir('./AM_time_series_WY/48-h_AM_time_series/ROS')

if not os.path.isdir('./AM_time_series_WY/48-h_AM_time_series/Rain'):
	os.mkdir('./AM_time_series_WY/48-h_AM_time_series/Rain')



if not os.path.isdir('./AM_time_series_WY/72-h_AM_time_series/W'):
	os.mkdir('./AM_time_series_WY/72-h_AM_time_series/W')

if not os.path.isdir('./AM_time_series_WY/72-h_AM_time_series/TF'):
	os.mkdir('./AM_time_series_WY/72-h_AM_time_series/TF')

if not os.path.isdir('./AM_time_series_WY/72-h_AM_time_series/Melt'):
	os.mkdir('./AM_time_series_WY/72-h_AM_time_series/Melt')

if not os.path.isdir('./AM_time_series_WY/72-h_AM_time_series/ROS'):
	os.mkdir('./AM_time_series_WY/72-h_AM_time_series/ROS')

if not os.path.isdir('./AM_time_series_WY/72-h_AM_time_series/Rain'):
	os.mkdir('./AM_time_series_WY/72-h_AM_time_series/Rain')












# --------------------------------------------------------------------------------------------------------------
# loop through each cell
def gen_ascii_WY(i, coor, datetime_24h):

	num_daily = 23375
	output_24h = npnan(num_daily, 6)  # 0-year, 1-mon, 2-day, 3-W_veg (mm), 4-P_int (mm), 5-SWE (mm)

	output_24h[:,0:3] = datetime_24h



	# load the data
	file_path = './24-h_time_series/data_%8.5f_%9.5f'   %( coor[i,0], coor[i,1])
	lines = [line.rstrip('\n') for line in open(file_path)]	

	# load the daily time series first
	count = 0
	for line in lines:
		item = line.split()  # any space

		output_24h[count, 3] = float(item[0])   # 0-W_veg (mm), 1-P (mm), 2-P_int (mm), 3-SWE (mm) in 24-hour time series
		output_24h[count, 4] = float(item[2])
		output_24h[count, 5] = float(item[3])

		count += 1



	# agg data into 48hour
	output_48h = npnan(num_daily-1, 6)
	for k in range(num_daily-1):
		output_48h[k,0:3] = output_24h[k+1,0:3]
		output_48h[k,3] = output_24h[k+1,3] + output_24h[k,3]
		output_48h[k,4] = output_24h[k+1,4] + output_24h[k,4]
		output_48h[k,5] = output_24h[k+1,5]

	# agg data into 72hour
	output_72h = npnan(num_daily-2, 6)
	for k in range(num_daily-2):
		output_72h[k,0:3] = output_24h[k+2,0:3]
		output_72h[k,3] = output_24h[k+2,3] + output_24h[k+1,3] + output_24h[k,3]
		output_72h[k,4] = output_24h[k+2,4] + output_24h[k+1,4] + output_24h[k,4]
		output_72h[k,5] = output_24h[k+2,5]








	s_yr = 1951
	e_yr = 2013
	num_year = e_yr - s_yr + 1

	annual_max_SWE = npnan(num_year, 4)  # 0-year, month, day, AM (mm)

	annual_max_24h_W_veg = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_24h_P_int = npnan(num_year, 4)  # 0-year, month, day

	annual_max_48h_W_veg = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_48h_P_int = npnan(num_year, 4)  # 0-year, month, day

	annual_max_72h_W_veg = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_72h_P_int = npnan(num_year, 4)  # 0-year, month, day


	annual_max_24h_melt = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_24h_ROS  = npnan(num_year, 4)  # 0-year, month, day
	annual_max_24h_rain = npnan(num_year, 4)

	annual_max_48h_melt = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_48h_ROS  = npnan(num_year, 4)  # 0-year, month, day
	annual_max_48h_rain = npnan(num_year, 4)

	annual_max_72h_melt = npnan(num_year, 4)  # 0-year, month, day, AM (mm)
	annual_max_72h_ROS  = npnan(num_year, 4)  # 0-year, month, day
	annual_max_72h_rain = npnan(num_year, 4)





	# extract the annual maximum value
	count = 0
	for yr in range(s_yr, e_yr+1):


		index1 = finddate(yr-1, 10, 1, output_24h)
		index2 = finddate(yr, 9, 30, output_24h)
		year_data_24h = output_24h[index1:index2+1,:]


		index1 = finddate(yr-1, 10, 2, output_48h)
		index2 = finddate(yr, 9, 30, output_48h)
		year_data_48h = output_48h[index1:index2+1,:]

		index1 = finddate(yr-1, 10, 3, output_72h)
		index2 = finddate(yr, 9, 30, output_72h)		
		year_data_72h = output_72h[index1:index2+1,:]



		annual_max_SWE[count, 3] = np.max(year_data_24h[:,5])
		annual_max_SWE[count, 0:3] = year_data_24h[np.argmax(year_data_24h[:,5]), 0:3]

		annual_max_24h_W_veg[count, 3] = np.max(year_data_24h[:,3])
		annual_max_24h_W_veg[count, 0:3] = year_data_24h[np.argmax(year_data_24h[:,3]), 0:3]

		annual_max_24h_P_int[count, 3] = np.max(year_data_24h[:,4])
		annual_max_24h_P_int[count, 0:3] = year_data_24h[np.argmax(year_data_24h[:,4]), 0:3]

		annual_max_48h_W_veg[count, 3] = np.max(year_data_48h[:,3])
		annual_max_48h_W_veg[count, 0:3] = year_data_48h[np.argmax(year_data_48h[:,3]), 0:3]

		annual_max_48h_P_int[count, 3] = np.max(year_data_48h[:,4])
		annual_max_48h_P_int[count, 0:3] = year_data_48h[np.argmax(year_data_48h[:,4]), 0:3]

		annual_max_72h_W_veg[count, 3] = np.max(year_data_72h[:,3])
		annual_max_72h_W_veg[count, 0:3] = year_data_72h[np.argmax(year_data_72h[:,3]), 0:3]

		annual_max_72h_P_int[count, 3] = np.max(year_data_72h[:,4])
		annual_max_72h_P_int[count, 0:3] = year_data_72h[np.argmax(year_data_72h[:,4]), 0:3]



		# ----------------------------------------------------------------
		# classify 24h daily event
		days = len(year_data_24h[:,0]) 
		# 0-year, 1-mon, 2-day, 3-value (mm)
		year_data_24h_melt = npnan(days, 4); year_data_24h_melt[:] = 0;   year_data_24h_melt[:, 0:3] = year_data_24h[:, 0:3]
		year_data_24h_ROS  = npnan(days, 4); year_data_24h_ROS[:] = 0;    year_data_24h_ROS[:, 0:3]  = year_data_24h[:, 0:3]
		year_data_24h_rain = npnan(days, 4); year_data_24h_rain[:] = 0;   year_data_24h_rain[:, 0:3] = year_data_24h[:, 0:3]

		for kk in range(1, days):
			w1 = year_data_24h[kk,3]
			p1 = year_data_24h[kk,4]
			swe = year_data_24h[kk,5]
			deltaswe = year_data_24h[kk,5] - year_data_24h[kk-1,5]

			if year_data_24h[kk-1,5]==0 and deltaswe==0:
				year_data_24h_rain[kk,3] = w1
			if (deltaswe<0 and p1==0): #or (deltaswe>0 and p1>deltaswe):
				year_data_24h_melt[kk,3] = w1
			if (p1-deltaswe)>0 and p1>=10 and year_data_24h[kk-1,5]>=10 and (-deltaswe/(p1-deltaswe))>=0.2:
				year_data_24h_ROS[kk,3] = w1

		annual_max_24h_melt[count, 3] = np.max(year_data_24h_melt[:,3])
		annual_max_24h_melt[count, 0:3] = year_data_24h_melt[np.argmax(year_data_24h_melt[:,3]), 0:3]

		annual_max_24h_rain[count, 3] = np.max(year_data_24h_rain[:,3])
		annual_max_24h_rain[count, 0:3] = year_data_24h_rain[np.argmax(year_data_24h_rain[:,3]), 0:3]

		annual_max_24h_ROS[count, 3] = np.max(year_data_24h_ROS[:,3])
		annual_max_24h_ROS[count, 0:3] = year_data_24h_ROS[np.argmax(year_data_24h_ROS[:,3]), 0:3]		



		# ----------------------------------------------------------------
		# classify 48h daily event
		days = len(year_data_48h[:,0]) 
		# 0-year, 1-mon, 2-day, 3-value (mm)
		year_data_48h_melt = npnan(days, 4); year_data_48h_melt[:] = 0;   year_data_48h_melt[:, 0:3] = year_data_48h[:, 0:3]
		year_data_48h_ROS  = npnan(days, 4); year_data_48h_ROS[:] = 0;    year_data_48h_ROS[:, 0:3]  = year_data_48h[:, 0:3]
		year_data_48h_rain = npnan(days, 4); year_data_48h_rain[:] = 0;   year_data_48h_rain[:, 0:3] = year_data_48h[:, 0:3]

		for kk in range(1, days):
			w1 = year_data_48h[kk,3]
			p1 = year_data_48h[kk,4]
			swe = year_data_48h[kk,5]
			deltaswe = year_data_48h[kk,5] - year_data_48h[kk-1,5]

			if year_data_48h[kk-1,5]==0 and deltaswe==0:
				year_data_48h_rain[kk,3] = w1
			if (deltaswe<0 and p1==0): #or (deltaswe>0 and p1>deltaswe):
				year_data_48h_melt[kk,3] = w1
			if (p1-deltaswe)>0 and p1>=10 and year_data_48h[kk-1,5]>=10 and (-deltaswe/(p1-deltaswe))>=0.2:
				year_data_48h_ROS[kk,3] = w1

		annual_max_48h_melt[count, 3] = np.max(year_data_48h_melt[:,3])
		annual_max_48h_melt[count, 0:3] = year_data_48h_melt[np.argmax(year_data_48h_melt[:,3]), 0:3]

		annual_max_48h_rain[count, 3] = np.max(year_data_48h_rain[:,3])
		annual_max_48h_rain[count, 0:3] = year_data_48h_rain[np.argmax(year_data_48h_rain[:,3]), 0:3]

		annual_max_48h_ROS[count, 3] = np.max(year_data_48h_ROS[:,3])
		annual_max_48h_ROS[count, 0:3] = year_data_48h_ROS[np.argmax(year_data_48h_ROS[:,3]), 0:3]	


		# ----------------------------------------------------------------
		# classify 72h daily event
		days = len(year_data_72h[:,0]) 
		# 0-year, 1-mon, 2-day, 3-value (mm)
		year_data_72h_melt = npnan(days, 4); year_data_72h_melt[:] = 0;   year_data_72h_melt[:, 0:3] = year_data_72h[:, 0:3]
		year_data_72h_ROS  = npnan(days, 4); year_data_72h_ROS[:] = 0;    year_data_72h_ROS[:, 0:3]  = year_data_72h[:, 0:3]
		year_data_72h_rain = npnan(days, 4); year_data_72h_rain[:] = 0;   year_data_72h_rain[:, 0:3] = year_data_72h[:, 0:3]

		for kk in range(1, days):
			w1 = year_data_72h[kk,3]
			p1 = year_data_72h[kk,4]
			swe = year_data_72h[kk,5]
			deltaswe = year_data_72h[kk,5] - year_data_72h[kk-1,5]

			if year_data_72h[kk-1,5]==0 and deltaswe==0:
				year_data_72h_rain[kk,3] = w1
			if (deltaswe<0 and p1==0): #or (deltaswe>0 and p1>deltaswe):
				year_data_72h_melt[kk,3] = w1
			if (p1-deltaswe)>0 and p1>=10 and year_data_72h[kk-1,5]>=10 and (-deltaswe/(p1-deltaswe))>=0.2:
				year_data_72h_ROS[kk,3] = w1

		annual_max_72h_melt[count, 3] = np.max(year_data_72h_melt[:,3])
		annual_max_72h_melt[count, 0:3] = year_data_72h_melt[np.argmax(year_data_72h_melt[:,3]), 0:3]

		annual_max_72h_rain[count, 3] = np.max(year_data_72h_rain[:,3])
		annual_max_72h_rain[count, 0:3] = year_data_72h_rain[np.argmax(year_data_72h_rain[:,3]), 0:3]

		annual_max_72h_ROS[count, 3] = np.max(year_data_72h_ROS[:,3])
		annual_max_72h_ROS[count, 0:3] = year_data_72h_ROS[np.argmax(year_data_72h_ROS[:,3]), 0:3]	



		count+=1










	# save the output

	outputfile = './AM_time_series_WY/SWE_AM_time_series/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_SWE, fmt='%d %d %d %5.4f')



	outputfile = './AM_time_series_WY/24-h_AM_time_series/W/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_24h_W_veg, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/24-h_AM_time_series/TF/data_%8.5f_%9.5f'   %( coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_24h_P_int, fmt='%d %d %d %5.4f')


	outputfile = './AM_time_series_WY/48-h_AM_time_series/W/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_48h_W_veg, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/48-h_AM_time_series/TF/data_%8.5f_%9.5f'   %( coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_48h_P_int, fmt='%d %d %d %5.4f')


	outputfile = './AM_time_series_WY/72-h_AM_time_series/W/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_72h_W_veg, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/72-h_AM_time_series/TF/data_%8.5f_%9.5f'   %( coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_72h_P_int, fmt='%d %d %d %5.4f')





	outputfile = './AM_time_series_WY/24-h_AM_time_series/Rain/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_24h_rain, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/24-h_AM_time_series/Melt/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_24h_melt, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/24-h_AM_time_series/ROS/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_24h_ROS, fmt='%d %d %d %5.4f')


	outputfile = './AM_time_series_WY/48-h_AM_time_series/Rain/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_48h_rain, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/48-h_AM_time_series/Melt/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_48h_melt, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/48-h_AM_time_series/ROS/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_48h_ROS, fmt='%d %d %d %5.4f')


	outputfile = './AM_time_series_WY/72-h_AM_time_series/Rain/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_72h_rain, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/72-h_AM_time_series/Melt/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_72h_melt, fmt='%d %d %d %5.4f')

	outputfile = './AM_time_series_WY/72-h_AM_time_series/ROS/data_%8.5f_%9.5f'   %(coor[i,0], coor[i,1])
	np.savetxt(outputfile, annual_max_72h_ROS, fmt='%d %d %d %5.4f')



	# monitor the process
	print(i, num_cell)







num_cores = multiprocessing.cpu_count()
# num_cores = 1
Parallel(n_jobs=num_cores)(delayed(gen_ascii_WY)(i, coor, datetime_24h) for i in range(num_cell))





