# ------------------------------------------------------------------------------------------------------------------------
# This is the R script used to do the nonparametric Mann-Kendall test for the annual max data
# calculate the trend (Sen's slope) based on the alpha = 5% significance level 
# written by Hongxiang Yan at PNNL, May 18, 2017
# ------------------------------------------------------------------------------------------------------------------------

library(trend)

#setwd('E:\\hongxiang\\Veg_NG-IDF')   # set the environmental directory

num_cell = 207173             # total num of cells over CONUS (1/16 degree)



coor <- data.matrix(read.table('../dem_livneh', header=FALSE))
coor <- coor[,1:2]            # 1st col -> lat; 2nd col -> lon

# prepare a matrix to store the trend analysis result
trend_res <- matrix(data=NaN, nrow=num_cell, ncol=3)   
# 1-lat, 2-lon, 3-Sen's slope (mm/yr), the row order associated with the coor
trend_res[,1:2] <- coor




# -----------------------------------------------------------------------------
# define M-K test function

MannKendall <- function(data) {   # data is a n x 1 vector
  res <- mk.test(ts(data))
  pvalue <- res[[2]]
  
  # if all 0 values or the same value
  if (is.nan(pvalue)) {
    slope = 0
  # if pvalue is not NaN
  } else {  
    if (pvalue > 0.05) {
      slope = 0   # no significant trend
    } else {
      res <- sens.slope(ts(data), conf.level = 0.95)  # significant trend
      slope = res$estimates
    }
  }
  return(slope)
}



# -----------------------------------------------------------------------------
# M-K test on different valirable 
for (id in 1:num_cell) {
  
  # load the annual max data
  file_name <- sprintf('./AM_time_series_CY/SWE_AM_time_series/data_%5.5f_%5.5f',  coor[id,1], coor[id,2])
  data <- data.matrix(read.table(file_name, header=FALSE))  # 1-col: year; 2-col: annumal max value (mm)
  
  # remove the first year (1951)
  data1 <- data[-1,]
  
  data1 <- data1[,4]

  # do the M-K
  trend_res[id,3] <- MannKendall(data1)
  
  # monitor the process
  print(id)
  #if (id == ceiling(num_cell*0.2)) { cat('finished 20% ... \n')}
  #if (id == ceiling(num_cell*0.4)) { cat('finished 40% ... \n')}
  #if (id == ceiling(num_cell*0.6)) { cat('finished 60% ... \n')}
  #if (id == ceiling(num_cell*0.8)) { cat('finished 80% ... \n')}
}

# output results into local drive
file_name <- './trend_results_CY/AM_SWE'
write.table(trend_res, file_name, row.names=FALSE, col.names=FALSE) 









D = c('24-h', '48-h', '72-h')  

# loop each variables
for (flag in 1:5) {  
  
  if (flag == 1) {variable_name = 'Melt';      }
  if (flag == 2) {variable_name = 'Rain';      }
  if (flag == 3) {variable_name = 'ROS';      }
  if (flag == 4) {variable_name = 'TF';      }
  if (flag == 5) {variable_name = 'W';      }

  # range for 4 duration
  for (d in 1:length(D)) {
    
    duration = D[d]
    
    for (id in 1:num_cell) {
      
      # load the annual max data
      file_name <- sprintf('./AM_time_series_CY/%s_AM_time_series/%s/data_%5.5f_%5.5f', duration, variable_name, coor[id,1], coor[id,2])
      data <- data.matrix(read.table(file_name, header=FALSE))  # 1-col: year; 2-col: annumal max value (mm)
      
      # remove the first year (1951)
      data1 <- data[-1,]
      
      data1 <- data1[,4]
    
      # do the M-K
      trend_res[id,3] <- MannKendall(data1)
      
      # monitor the process
      print(id)
      #if (id == ceiling(num_cell*0.2)) { cat('finished 20% ... \n')}
      #if (id == ceiling(num_cell*0.4)) { cat('finished 40% ... \n')}
      #if (id == ceiling(num_cell*0.6)) { cat('finished 60% ... \n')}
      #if (id == ceiling(num_cell*0.8)) { cat('finished 80% ... \n')}
    }
    
    # output results into local drive
    file_name <- sprintf('./trend_results_CY/%s_%s', duration, variable_name)
    write.table(trend_res, file_name, row.names=FALSE, col.names=FALSE) 
    
  }
}
  
  



 
  
  
  
  
  
  
















