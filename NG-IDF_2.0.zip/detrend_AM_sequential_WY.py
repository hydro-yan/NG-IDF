#--------------------------------------------------------------------------------------------------------------
# This is a Python3 script used to detrend the annual maximum datas for CONUS
# written by Hongxiang Yan at PNNL on May 25, 2018
#--------------------------------------------------------------------------------------------------------------
import numpy as np
import os
import copy
import math
import re
import csv
import shutil
import datetime
import pandas as pd
import scipy
import os.path
from joblib import Parallel, delayed  
import multiprocessing



#--------------------------------------------------------------------------------------------------------------
def npnan(x,y):
	#this function creates the np.nan 2d-array (np.nan should be float)
 	array_2d = np.zeros((x,y), float) 
 	array_2d[:] = np.nan
 	return array_2d





#--------------------------------------------------------------------------------------------------------------
# starts here
num_cell = 207173

# load the lat, lon, and cluster
coor = npnan(num_cell, 3) # 0-lat, 1-lon, 2-cluster id (1-5)
file_name = '../cluster_conus.csv'
lines = [line.rstrip('\n') for line in open(file_name)]
lines = lines[1:]
count = 0
for line in lines:
	item = line.split(',')
	coor[count, 0] = float(item[1])  # lat
	coor[count, 1] = float(item[2])  # lon
	coor[count, 2] = float(item[3])  # cluster ID
	count += 1




# if path doesnot exist, create path
if not os.path.isdir('./d_AM_time_series_WY/24-h_AM_time_series'):
	os.mkdir('./d_AM_time_series_WY/24-h_AM_time_series')	

if not os.path.isdir('./d_AM_time_series_WY/48-h_AM_time_series'):
	os.mkdir('./d_AM_time_series_WY/48-h_AM_time_series')

if not os.path.isdir('./d_AM_time_series_WY/72-h_AM_time_series'):
	os.mkdir('./d_AM_time_series_WY/72-h_AM_time_series')

if not os.path.isdir('./d_AM_time_series_WY/SWE_AM_time_series'):
	os.mkdir('./d_AM_time_series_WY/SWE_AM_time_series')	


if not os.path.isdir('./d_AM_time_series_WY/24-h_AM_time_series/W'):
	os.mkdir('./d_AM_time_series_WY/24-h_AM_time_series/W')

if not os.path.isdir('./d_AM_time_series_WY/24-h_AM_time_series/TF'):
	os.mkdir('./d_AM_time_series_WY/24-h_AM_time_series/TF')

if not os.path.isdir('./d_AM_time_series_WY/24-h_AM_time_series/Melt'):
	os.mkdir('./d_AM_time_series_WY/24-h_AM_time_series/Melt')

if not os.path.isdir('./d_AM_time_series_WY/24-h_AM_time_series/ROS'):
	os.mkdir('./d_AM_time_series_WY/24-h_AM_time_series/ROS')

if not os.path.isdir('./d_AM_time_series_WY/24-h_AM_time_series/Rain'):
	os.mkdir('./d_AM_time_series_WY/24-h_AM_time_series/Rain')



if not os.path.isdir('./d_AM_time_series_WY/48-h_AM_time_series/W'):
	os.mkdir('./d_AM_time_series_WY/48-h_AM_time_series/W')

if not os.path.isdir('./d_AM_time_series_WY/48-h_AM_time_series/TF'):
	os.mkdir('./d_AM_time_series_WY/48-h_AM_time_series/TF')

if not os.path.isdir('./d_AM_time_series_WY/48-h_AM_time_series/Melt'):
	os.mkdir('./d_AM_time_series_WY/48-h_AM_time_series/Melt')

if not os.path.isdir('./d_AM_time_series_WY/48-h_AM_time_series/ROS'):
	os.mkdir('./d_AM_time_series_WY/48-h_AM_time_series/ROS')

if not os.path.isdir('./d_AM_time_series_WY/48-h_AM_time_series/Rain'):
	os.mkdir('./d_AM_time_series_WY/48-h_AM_time_series/Rain')



if not os.path.isdir('./d_AM_time_series_WY/72-h_AM_time_series/W'):
	os.mkdir('./d_AM_time_series_WY/72-h_AM_time_series/W')

if not os.path.isdir('./d_AM_time_series_WY/72-h_AM_time_series/TF'):
	os.mkdir('./d_AM_time_series_WY/72-h_AM_time_series/TF')

if not os.path.isdir('./d_AM_time_series_WY/72-h_AM_time_series/Melt'):
	os.mkdir('./d_AM_time_series_WY/72-h_AM_time_series/Melt')

if not os.path.isdir('./d_AM_time_series_WY/72-h_AM_time_series/ROS'):
	os.mkdir('./d_AM_time_series_WY/72-h_AM_time_series/ROS')

if not os.path.isdir('./d_AM_time_series_WY/72-h_AM_time_series/Rain'):
	os.mkdir('./d_AM_time_series_WY/72-h_AM_time_series/Rain')













# duration
D = ['24-h', '48-h', '72-h']
# D = ['72-h']



# # --------------------------------------------------------------------------------------------------------------
# # loop through each cell
# def gen_ascii(i, lulc, coor):



for d in range(len(D)):

	duration = D[d]

	for flag in range(5):

		# -------------------------------------------------------------
		# identify variable name
		if flag == 0:
			var_name = 'W';  trend_var = '%s_%s' %(duration, var_name)        

		if flag == 1:
			var_name = 'TF';  trend_var = '%s_%s' %(duration, var_name)        

		if flag == 2:
			var_name = 'Melt';  trend_var = '%s_%s' %(duration, var_name)   

		if flag == 3:
			var_name = 'Rain';  trend_var = '%s_%s' %(duration, var_name)   

		if flag == 4:
			var_name = 'ROS';  trend_var = '%s_%s' %(duration, var_name)   




		# -------------------------------------------------------------
		# load the Sen's slope into RAM
		sen_slope = npnan(num_cell, 3) 

		file_name = './trend_results_WY/%s'  %(trend_var, )
		lines = [line.rstrip('\n') for line in open(file_name)]	
		count = 0
		for line in lines:
			item = line.split()
			sen_slope[count,0] = float(item[0])
			sen_slope[count,1] = float(item[1])
			sen_slope[count,2] = float(item[2])
			count += 1


		# -------------------------------------------------------------
		# start detrend
		for cell in range(num_cell):

			# detecting no trend
			if sen_slope[cell,2] == 0:   
				from_dir = './AM_time_series_WY/%s_AM_time_series/%s/data_%8.5f_%9.5f'  %(duration, var_name, sen_slope[cell,0], sen_slope[cell,1])
				to_dir   = './d_AM_time_series_WY/%s_AM_time_series/%s/data_%8.5f_%9.5f'  %(duration, var_name, sen_slope[cell,0], sen_slope[cell,1])
				shutil.copyfile(from_dir, to_dir)

				# # delete the first line
				# with open(to_dir, 'r') as fin:
				# 	data = fin.read().splitlines(True)
				# with open(to_dir, 'w') as fout:
				# 	fout.writelines(data[1:])


			# detecting trend
			else:
				#load the data into RAM
				file_name = './AM_time_series_WY/%s_AM_time_series/%s/data_%8.5f_%9.5f'  %(duration, var_name, sen_slope[cell,0], sen_slope[cell,1])
				lines = [line.rstrip('\n') for line in open(file_name)]	
				# lines = lines[1:]

				#prepare a np.array to catch the data
				var = npnan(len(lines), 4)                #0-year; 1-mon, 2-day, 3-AM
				detrend_data = npnan(len(lines), 4)       #0-year; 1-mon, 2-day, 3-AM

				#load the data into the np.array
				day = 0
				for line in lines:
					item = line.split()
					for k in range(len(var[0,:])):
						var[day, k] = float(item[k])
					day += 1

				detrend_data[:,0:3] = var[:,0:3]  


				# detrend the data while keep the mean average
				if (len(lines)%2) == 0:  #even number
					mid_point = int(len(lines)/2 - 1)
					for j in range(0, mid_point):
						detrend_data[j,3] = var[j,3] + sen_slope[cell,2]*(mid_point-j)
					for j in range(mid_point+2, len(lines)):
						detrend_data[j,3] = var[j,3] - sen_slope[cell,2]*(j-mid_point)
					detrend_data[mid_point,3]   = var[mid_point,3]   + sen_slope[cell,2]*0.5
					detrend_data[mid_point+1,3] = var[mid_point+1,3] - sen_slope[cell,2]*0.5
				else:    #odd number
					mid_point = int((len(lines)+1)/2 - 1)
					for j in range(0, mid_point):
						detrend_data[j,3] = var[j,3] + sen_slope[cell,2]*(mid_point-j)
					for j in range(mid_point, len(lines)):
						detrend_data[j,3] = var[j,3] - sen_slope[cell,2]*(j-mid_point)
				try:
					assert(abs(np.mean(detrend_data[:,3])-np.mean(var[:,3]))<2e-1)
				except:
					print(np.mean(detrend_data[:,3]), np.mean(var[:,3]))
					print('the mean detrended data is not equal to the mean original data')
					print('the duration: %d, the variable name is: %s, the cell number is: %d, the coordinate is: %8.5f, %9.5f') %(duration, variable_name, cell+1, sen_slope[cell,0], sen_slope[cell,1])
					exit()


				# -------------------------------------------------------------
				# output the file
				outputfile = './d_AM_time_series_WY/%s_AM_time_series/%s/data_%8.5f_%9.5f'  %(duration, var_name, sen_slope[cell,0], sen_slope[cell,1])
				np.savetxt(outputfile, detrend_data, fmt='%d %d %d %5.4f')		



			# monitor the process
			print(var_name, duration, cell, num_cell)







# num_cores = multiprocessing.cpu_count()
# num_cores = 48
# Parallel(n_jobs=num_cores)(delayed(gen_ascii)(i, lulc, coor) for i in range(num_cell))