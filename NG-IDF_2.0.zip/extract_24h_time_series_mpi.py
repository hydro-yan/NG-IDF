#--------------------------------------------------------------------------------------------------------------
# This is a Python3 script to extract DHSVM 3-hour for CONUS runs 


#--------------------------------------------------------------------------------------------------------------
import numpy as np
import os
import copy
import math
import re
import csv
import shutil
import datetime
import pandas as pd
import scipy
import os.path
# from joblib import Parallel, delayed  
# import multiprocessing
from mpi4py import MPI

#--------------------------------------------------------------------------------------------------------------
def npnan(x,y):
	#this function creates the np.nan 2d-array (np.nan should be float)
 	array_2d = np.zeros((x,y), float) 
 	array_2d[:] = np.nan
 	return array_2d

#--------------------------------------------------------------------------------------------------------------
def finddate(year,month,day,var):
	#given year month day and find the index number in the var array
	#if the year/month/day is not in the var, return the last day of var 
	#input year/month/day: int
	var = var[:,:3]        #only contains the date
	var = var.astype(int)  #float to int
	date = np.array([year,month,day])
	temp = np.where(np.all(var==date, axis=1))  #return a tuple
	try:
		m = int(temp[0])
	except:
		m = len(var[:, 0])-1
	return m



#--------------------------------------------------------------------------------------------------------------
# starts here
num_cell = 207173

# load the lat, lon, and cluster
coor = npnan(num_cell, 3) # 0-lat, 1-lon, 2-cluster id (1-5)
file_name = '/rcfs/projects/estcp_ngidf/hongxiang/Arcgis/arcpy/cluster_conus.csv'
lines = [line.rstrip('\n') for line in open(file_name)]
lines = lines[1:]
count = 0
for line in lines:
	item = line.split(',')
	coor[count, 0] = float(item[1])  # lat
	coor[count, 1] = float(item[2])  # lon
	coor[count, 2] = float(item[3])  # cluster ID
	count += 1


# load LULC
lulc = ['Evergreen']


comm = MPI.COMM_WORLD
rank = comm.Get_rank()     # the process ID (integer 0-22 for 23-process run)
size = 240                 # the total amount of process requested, define in the command, 1-24 for hydronet

# split cells for each processors
rank_cell = math.floor(num_cell/size)   #863
last_rank_cell = num_cell - rank_cell*(size-1)  #916

# assign number of cells into each processors
if rank < (size-1):    # not the last rank
	loop_cell = rank_cell
else:                  # the last rank
	loop_cell = last_rank_cell



# load the date file
num_3h = 187000
date_3h = npnan(num_3h, 4)    # 0-year, 1-mon, 2-day, 3-hour
file_path = './datetime_3h' 
lines = [line.rstrip('\n') for line in open(file_path)]	
count = 0
for line in lines:
	item = line.split()  # any space
	for k in range(len(item)):
		date_3h[count, k] = float(item[k])
	count += 1	




# --------------------------------------------------------------------------------------------------------------
# loop through each cell
for m in range(loop_cell):

	num_3h = 187000
	output_3h = npnan(num_3h, 4)  # 0-W_veg (mm), 1-P (mm), 2-P_int (mm), 3-SWE (mm)
	
	for j in range(len(lulc)):

		# load the data
		file_path = '/rcfs/projects/estcp_ngidf/duan224/enhanced_idf/conus_run/%s/%8.5f_%9.5f/Pixel.CENTER'   %(lulc[j], coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
		lines = [line.rstrip('\n') for line in open(file_path)]	

		lines = [line.rstrip('\n') for line in open(file_path)]	
		lines = lines[2:]    # remove the first 2 lines

		# extract the 3 hour time series first
		count = 0
		for line in lines:
			item = line.split()  # any space
			output_3h[count, 0] = float(item[2])        # W_veg  (mm)
			output_3h[count, 1] = float(item[3])*1000   # P  (mm)
			output_3h[count, 2] = float(item[5])*1000   # P_int (mm)
			output_3h[count, 3] = float(item[13])*1000  # SWE(mm)
			count += 1
			if count==num_3h:
				break


		# post-processing, making sure all value >0 
		for k in range(4):
			output_3h[output_3h[:,k]<=0, k] = 0




		# agg into daily time step first
		num_day = int(num_3h/8)
		output_daily = npnan(num_day, 7)  # 0-year, 1-mon, 2-day, 3-W_veg (mm), 4-P (mm), 5-P_int (mm), 6-SWE (mm), 
		for k in range(num_day):
			output_daily[k, 0:3] = date_3h[k*8, 0:3]
			output_daily[k, 3] = np.sum(output_3h[k*8:(k+1)*8, 0])
			output_daily[k, 4] = np.sum(output_3h[k*8:(k+1)*8, 1])
			output_daily[k, 5] = np.sum(output_3h[k*8:(k+1)*8, 2])
			output_daily[k, 6] = output_3h[(k+1)*8-1, 3]
	
		


		# # save the datetime file
		# if rank*rank_cell+m == 0:
		# 	outfile = '/rcfs/projects/estcp_ngidf/hongxiang/Veg_NG-IDF/%s/datetime_24h'  %(lulc[j], )
		# 	np.savetxt(outfile, output_daily[:,0:3], fmt='%d %d %d')




		# save the output
		outputfile = '/rcfs/projects/estcp_ngidf/hongxiang/Veg_NG-IDF/%s/24-h_time_series/data_%8.5f_%9.5f'   %(lulc[j], coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])
		np.savetxt(outputfile, output_daily[:,3:7], fmt='%6.5f %6.5f %6.5f %6.5f')



	print(rank, m, loop_cell, coor[rank*rank_cell+m,0], coor[rank*rank_cell+m,1])









