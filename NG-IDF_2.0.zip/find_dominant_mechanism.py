#--------------------------------------------------------------------------------------------------------------
# This is a Python3 script used to detrend the annual maximum datas for CONUS
# written by Hongxiang Yan at PNNL on May 25, 2018
#--------------------------------------------------------------------------------------------------------------
import numpy as np
import os
import copy
import math
import re
import csv
import shutil
import datetime
import pandas as pd
import scipy
import os.path
from joblib import Parallel, delayed  
import multiprocessing



#--------------------------------------------------------------------------------------------------------------
def npnan(x,y):
	#this function creates the np.nan 2d-array (np.nan should be float)
 	array_2d = np.zeros((x,y), float) 
 	array_2d[:] = np.nan
 	return array_2d









#--------------------------------------------------------------------------------------------------------------
# starts here
num_cell = 207173



duration = ['24-h', '48-h', '72-h']
folder = ['IDF_curves_CY', 'IDF_curves_CY_detrend', 'IDF_curves_WY', 'IDF_curves_WY_detrend']


for ii in range(len(folder)):

	for jj in range(len(duration)):


		idf_melt = npnan(num_cell, 9)  #0-lat, 1-lon, 2-2-yr, 3-5-yr, 4-10-yr, 5-25-yr, 6-50-yr, 7-100-yr, 8-500-yr
		idf_rain = npnan(num_cell, 9)
		idf_ROS  = npnan(num_cell, 9)


		file_name = './%s/%s_Melt' %(folder[ii], duration[jj])
		lines = [line.rstrip('\n') for line in open(file_name)]
		count = 0
		for line in lines:
			item = line.split()
			for i in range(len(item)):
				try:
					idf_melt[count, i] = float(item[i])
				except:
					idf_melt[count, i] = np.nan
			count += 1


		file_name = './%s/%s_Rain' %(folder[ii], duration[jj])
		lines = [line.rstrip('\n') for line in open(file_name)]
		count = 0
		for line in lines:
			item = line.split()
			for i in range(len(item)):
				try:
					idf_rain[count, i] = float(item[i])
				except:
					idf_rain[count, i] = np.nan
			count += 1


		file_name = './%s/%s_ROS' %(folder[ii], duration[jj])
		lines = [line.rstrip('\n') for line in open(file_name)]
		count = 0
		for line in lines:
			item = line.split()
			for i in range(len(item)):
				try:
					idf_ROS[count, i] = float(item[i])
				except:
					idf_ROS[count, i] = np.nan
			count += 1





		# 1-Melt, 2-Rain, 3-ROS
		dominant = npnan(num_cell, 9)    #0-lat, 1-lon, 2-2-yr, 3-5-yr, 4-10-yr, 5-25-yr, 6-50-yr, 7-100-yr, 8-500-yr
		dominant[:,0:2] = idf_ROS[:,0:2]

		for i in range(num_cell):

			for j in range(7):
				melt = idf_melt[i,j+2]
				rain = idf_rain[i,j+2]
				ROS  = idf_ROS[i,j+2]

				if np.isnan(melt):
					melt = 0
				if np.isnan(rain):
					rain = 0
				if np.isnan(ROS):
					ROS = 0

				if melt==0 and rain==0 and ROS==0:
					print(idf_melt[i,:])
					print(idf_rain[i,:])
					print(idf_ROS[i,:])
					exit()

				if melt>rain and melt>ROS:
					dominant[i,j+2] = 1

				if rain>melt and rain>ROS:
					dominant[i,j+2] = 2

				if ROS>rain and ROS>melt:
					dominant[i,j+2] = 3

				if np.isnan(dominant[i,j+2]):
					print(idf_melt[i,:])
					print(idf_rain[i,:])
					print(idf_ROS[i,:])
					exit()			
			
			print(i)


		file = './%s/%s_dominant_mechanism' %(folder[ii], duration[jj])

		np.savetxt(file, dominant, fmt='%6.5f %6.5f %d %d %d %d %d %d %d')















