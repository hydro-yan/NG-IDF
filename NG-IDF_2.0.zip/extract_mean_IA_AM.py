#--------------------------------------------------------------------------------------------------------------
# This is a Python3 script used to detrend the annual maximum datas for CONUS
# written by Hongxiang Yan at PNNL on May 25, 2018
#--------------------------------------------------------------------------------------------------------------
import numpy as np
import os
import copy
import math
import re
import csv
import shutil
import datetime
import pandas as pd
import scipy
import os.path
from joblib import Parallel, delayed  
import multiprocessing



#--------------------------------------------------------------------------------------------------------------
def npnan(x,y):
	#this function creates the np.nan 2d-array (np.nan should be float)
 	array_2d = np.zeros((x,y), float) 
 	array_2d[:] = np.nan
 	return array_2d





#--------------------------------------------------------------------------------------------------------------
# starts here
num_cell = 207173

IA_mean = npnan(num_cell, 3) #0-lat, 1-lon, 2-ratio (mean of all AM data)

# load the lat, lon, and cluster
coor = npnan(num_cell, 3) # 0-lat, 1-lon, 2-cluster id (1-5)
file_name = './cluster_conus.csv'
lines = [line.rstrip('\n') for line in open(file_name)]
lines = lines[1:]
count = 0
for line in lines:
	item = line.split(',')
	coor[count, 0] = float(item[1])  # lat
	coor[count, 1] = float(item[2])  # lon
	coor[count, 2] = float(item[3])  # cluster ID
	count += 1

IA_mean[:,0:2] = coor[:,0:2]

#--------------------------------------------------------------------------------------------------------------
duration = '24-h'

for i in range(num_cell):

	

	#load the AM P
	file_name = '/files2/projects/estcp_ngidf/hongxiang/Veg_NG_IDF/Open/AM_time_series_CY/%s_AM_time_series/%s/data_%5.5f_%5.5f'   %(duration, 'P', coor[i,0], coor[i,1])
	lines = [line.rstrip('\n') for line in open(file_name)]	
	lines = lines[1:]    

	var = npnan(len(lines), 2)  #0-P, 1-P_int

	day = 0
	for line in lines:
		item = line.split()
		var[day, 0] = float(item[3])
		day += 1

	#load the AM P_int
	file_name = './AM_time_series_CY/%s_AM_time_series/%s/data_%5.5f_%5.5f'   %(duration, 'TF', coor[i,0], coor[i,1])
	lines = [line.rstrip('\n') for line in open(file_name)]	
	lines = lines[1:]    

	day = 0
	for line in lines:
		item = line.split()
		var[day, 1] = float(item[3])
		day += 1

	ratio = 1 - var[:,1]/var[:,0]
	ratio[ratio<0] = 0

	IA_mean[i,2] = np.mean(ratio)

	print(i)

np.savetxt('./mean_AM_IA_ratio', IA_mean, fmt='%5.5f %5.5f %5.5f')		
